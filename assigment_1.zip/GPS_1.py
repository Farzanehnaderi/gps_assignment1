import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
from mpl_toolkits.mplot3d import Axes3D

'''Farzaneh Naderi 810301115
GPS-practice 1'''
'''In this project, we want to investigate the simulation of the satellite path in 3D space.'''
#Earth's gravitational cities
mu = 398600  # km^3/s^2
R_earth = 6371  # Earth's radius (km)

# Equations of motion
def equations(t, state):
    x, y, z, vx, vy, vz = state
    r = np.sqrt(x**2 + y**2 + z**2)
    ax = -mu * x / r**3
    ay = -mu * y / r**3
    az = -mu * z / r**3
    return [vx, vy, vz, ax, ay, az]

# Initial conditions
r0 = [8000, 0, 6000]  # Initial position (km)
v0 = [0, 7, 0]        # Initial speed (km/s)
initial_state = r0 + v0

# Solution time frame (simulation time 4 hours)
t_span = (0, 14400)  # seconds
t_eval = np.linspace(0, 14400, 1000)  # Sampling points

# Solving differential equations with the RK45 method
solution = solve_ivp(equations, t_span, initial_state, t_eval=t_eval, method='RK45')

# Extract positions
x, y, z = solution.y[0], solution.y[1], solution.y[2]

# Calculate the distance from the center of the Earth
r = np.sqrt(x**2 + y**2 + z**2)

# Finding the Apogee and Perigee
apogee = np.max(r)
perigee = np.min(r)

# Calculate the distance from the center of the Earth
r = np.sqrt(x**2 + y**2 + z**2)
altitude = r - R_earth  # Height above ground level

# Distance from the ground
altitude_apogee = apogee - R_earth
altitude_perigee = perigee - R_earth

print(f"Apogee Altitude: {altitude_apogee:.2f} km")
print(f"Perigee Altitude: {altitude_perigee:.2f} km")

# Drawing the orbit of the satellite and the Earth
fig = plt.figure(figsize=(10, 10))
ax = fig.add_subplot(111, projection='3d')

# Drawing the orbit of the satellite
ax.plot(x, y, z, label="Orbit Path", color='orange')

# Draw the globe
u, v = np.mgrid[0:2*np.pi:50j, 0:np.pi:25j]
x_earth = R_earth * np.cos(u) * np.sin(v)
y_earth = R_earth * np.sin(u) * np.sin(v)
z_earth = R_earth * np.cos(v)
ax.plot_surface(x_earth, y_earth, z_earth, color='blue', alpha=0.6, edgecolor='k')

fig = plt.figure(figsize=(8, 8))
ax = fig.add_subplot(111, projection='3d')
ax.plot(x, y, z, label="Orbit Path")
ax.scatter(0, 0, 0, color='r', marker='o', label="Earth Center")
ax.legend()
ax.set_xlabel('X (km)')
ax.set_ylabel('Y (km)')
ax.set_zlabel('Z (km)')
plt.title("Satellite Orbit Simulation")
plt.show()

# Show chart settings
ax.set_xlabel('X (km)')
ax.set_ylabel('Y (km)')
ax.set_zlabel('Z (km)')
ax.set_title("Satellite Orbit Around Earth")
ax.legend()
plt.show()

#Drawing of changes in satellite altitude from the Earth's surface
plt.figure()
plt.plot(solution.t / 60, altitude, label='Altitude (km)')
plt.xlabel('Time (minutes)')
plt.ylabel('Altitude (km)')
plt.title('Satellite Altitude Over Time')
plt.legend()
plt.grid()
plt.show()
